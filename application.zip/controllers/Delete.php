<?php

class Delete extends CI_Controller
{
    public function delete_token()
    {
        
    }
}
