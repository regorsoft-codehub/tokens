    <div class="sidebar" data-color="purple" data-image="<?php echo base_url('assets/img/sidebar-5.jpg')?>">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="<?php echo base_url('dashboard');?>" class="simple-text">
                    TOKENS
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="<?php echo base_url('dashboard');?>">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="">
                    <a href="<?php echo base_url('dashboard/viewtokens');?>">
                        <i class="pe-7s-ticket"></i>
                        <p>TOKENS</p>
                    </a>
                </li>
                <?php if(onlyAdmin()): ?>
                  <li>
                    <a href="user.html">
                        <i class="pe-7s-user"></i>
                        <p>MANAGERS</p>
                    </a>
                </li>
                <li>
                    <a href="table.html">
                        <i class="pe-7s-user"></i>
                        <p>AGENTS</p>
                    </a>
                </li>
                <li>
                    <a href="typography.html">
                        <i class="pe-7s-user"></i>
                        <p>CLEINTS</p>
                    </a>
                </li>
                <li>
                    <a href="icons.html">
                        <i class="fa fa-history" aria-hidden="true"></i>
                        <p>ALL TRANSACTIONS</p>
                    </a>
                </li>                    
                <?php endif;?>
               
                
		<li class="active-pro">
                    <a href="#">
                        <i class="fa fa-power-off" aria-hidden="true"></i>
                        <p>LOG OUT</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>