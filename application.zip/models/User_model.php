<?php

class User_model extends CI_model
{
    public function get_user_byid($id, $tbl_name)
    {
       $query = $this->db->get_where($tbl_name, array('id =' => $id));
       $ret = $query->row();
       echo($ret->id);
    }
}

