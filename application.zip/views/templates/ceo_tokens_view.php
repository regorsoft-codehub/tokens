<div class="wrapper">
    <?php $this->load->view('templates/sidebar');?>

    <div class="main-panel">
        <?php $this->load->view('templates/nav');?>
 <div class="alerts"></div>        
<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <div class="left-side">
                                    <h4 class="title">All tokens</h4>
                                    <p class="category">Add, edit and update tokens</p>
                                </div>
                                <input placeholder="Search tokens" class="w3-input w3-border b-right search-t" type="text">
                                <?php if(onlyAdmin()): ?>
                                <a class="w3-btn b-right" href="<?php echo base_url('dashboard/addtoken');?>">Add new</a>
                                <?php endif;?>
                            </div>
                            <div class="content table-responsive table-full-width">
                               
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>ID</th>
                                    	<th>TOKEN NAME</th>
                                    	<th>PRICE</th>
                                    	<th>DESCRIPTION</th>
                                        <?php if(onlyAdmin()): ?>
                                        <th>ACTION</th>
                                        <?php elseif(onlyClient()):?>
                                        <th>PURCHASE</th>
                                        <?php endif;?>
                                        
                                    </thead>
                                    <tbody>
                                         <?php foreach($allTokens as $tokens):?>
                                        <tr>
                                                <td><span class="label label-primary"><i class="fa fa-ticket" aria-hidden="true"></i> <?php echo $tokens->token_id;?></span><?php echo $tokens->id;?></td>
                                        	<td><?php echo $tokens->token_name;?></td>
                                        	<td><i class="fa fa-usd" aria-hidden="true"></i> <?php echo $tokens->price;?></td>
                                        	<td><?php echo $tokens->description;?></td>
                                        	<?php if(onlyAdmin()): ?>
                                                <td>
                                                    <button class="w3-btn w3-green"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button>
                                                    <a href="<?php echo base_url('dashboard/delete/'.$tokens->ukey); ?>"><button class="w3-btn w3-red"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                                </td>
                                                <?php elseif(onlyClient()):?>
                                                <td>
                                                    <?php if(in_cart($tokens->id)==true):?>
                                                    <button id="addcart-<?php echo $tokens->id; ?>" data="<?php echo $tokens->id; ?>" status="remove" class="w3-btn w3-green addcart" style="background: red;">Remove <i class="fa fa-times" aria-hidden="true"></i></button>
                                                    <?php else:?> 
                                                    <button id="addcart-<?php echo $tokens->id; ?>" data="<?php echo $tokens->id; ?>" status="add" class="w3-btn w3-green addcart"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Add to cart</button>
                                                    <?php endif;?>
                                                </td>
                                                <?php endif;?>
                                        </tr>
                                         <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
            </div>
        </div>
      <?php $this->load->view('templates/footer_view');?>

    </div>
</div>
</body>

   <?php $this->load->view('load_js');?>

</html>
