<!--<h7><center>Tokens in Cart</center></h7>
<hr>-->
<?php 
$price=[];
foreach($cart_items as $items):?>
<li><a href="#"><span class="label label-primary"><i class="fa fa-ticket" aria-hidden="true"></i><?php echo $items['token_id']?></span> <i class="fa fa-usd" aria-hidden="true"></i> <?php echo $items['price']?>
<?php $price[] = $items['price']?>
 <?php endforeach;?>
<!--<hr>-->

<center>
    <b style="color:#000">TOTAL:<i class="fa fa-usd" aria-hidden="true"></i><?php echo array_sum($price);?><br><button id="addcart-13" data="13" status="add" class="w3-btn w3-green addcart"><li><a style="color:#fff;margin-bottom: 1%"><i class="fa fa-sign-in" aria-hidden="true"></i> Check out</a></li></button></b></center>