<nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <?php if(onlyClient()):?>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                  <i class="fa fa-shopping-cart" id="sc" aria-hidden="true"><span id="cart-count" class="cart-count"><?php if(isset($_SESSION['test']) && count($_SESSION['test'])!==0)echo count($_SESSION['test']);?></span></i>
                                    <b class="caret"></b>
                              </a>
                             <ul class="dropdown-menu">
                             </ul>
                        </li> 
                        <?php endif;?>
                        <li>
                            <a href="<?php echo base_url("logout");?>">
                                <i class="fa fa-user" style="font-size: 30px" aria-hidden="true"></i>
                                &nbsp;Log out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav> 