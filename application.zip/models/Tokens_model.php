<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Tokens_model extends CI_Model{
    
    public function table_count($table) {
        $query = $this->db->query("SELECT 'id' FROM " . $table . "");
        return $query->num_rows();
    }
    public function allTokens()
    {
         $query = $this->db->get('tokens'); 
         return $query->result();
    }
}