<?php
if(isset($_SESSION['error']))
    {
    echo "<p style='color:red'>".$_SESSION['error']."</p>";
    
    }
    elseif(isset($_SESSION['success']))
    {
     echo "<p style='color:green'>".$_SESSION['success']."</p>";
    }
    
?>