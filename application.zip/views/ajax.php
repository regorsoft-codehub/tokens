<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
// function addCart(var id) {

// 	getParam(id);

//   }


    <?php if($_SESSION['success']){ ?>
        $(".alerts").html("<div class='alert alert-success alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>×</a><strong>Success!</strong> <?php echo $_SESSION['success']; ?></div>");
        $(".alerts").fadeOut(3000);
    <?php }?>
//});
</script>