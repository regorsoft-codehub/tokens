<div class="wrapper">
    <?php $this->load->view('templates/sidebar');?>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                     <!--    <li>
                           <a href="">
                               Account
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    Dropdown
                                    <b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                              </ul>
                        </li> -->
                        <li>
                            <a href="<?php echo base_url("logout");?>">
                                <i class="fa fa-user" style="font-size: 30px" aria-hidden="true"></i>
                                &nbsp;Log out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav> 
<div class="content">
	<div class="row">
	    <div class="col-md-8 col-md-offset-2">
	        <div class="alerts"></div>
    		<h2>Add new token</h2>

    		     <?php $attributes = array('class' => 'form-horizontal', 'id' => 'myform', 'method'=>'post');
                                            echo   form_open('dashboard/addtoken', $attributes);?>
    		    <div class="form-group">
    		        <label for="title">Title <span class="require">*</span></label>
    		        <input type="text" class="form-control" name="title" />
                        <span class="help-block"><?php echo form_error('title'); ?></span>
    		    </div>
                    <div class="form-group">
    		        <label for="price">Price <span class="require">*</span></label>
    		        <input type="text" class="form-control" name="price" />
                        <span class="help-block"><?php echo form_error('price'); ?></span>
    		    </div>
    		    
    		    <div class="form-group">
    		        <label for="description">Description</label>
    		        <textarea rows="5" class="form-control" name="description" ></textarea>
    		    </div>
    		    
    		    <div class="form-group">
    		        <p><span class="require">*</span> - required fields</p>
    		    </div>
    		    
    		    <div class="form-group">
    		        <button type="submit" class="btn btn-primary">
    		            Create
    		        </button>
<!--    		        <button class="btn btn-default">
    		            Cancel
    		        </button>-->
    		    </div>
    		    
    		</form>
		</div>
		
	</div>
        </div>
       <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="#">
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Company
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Portfolio
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               Blog
                            </a>
                        </li>
                    </ul>
                </nav>
                <p class="copyright pull-right">
                    &copy; 2016 <a href="#">Tokens</a>, It's all about tokens.
                </p>
            </div>
        </footer>

    </div>
</div>
</body>

<?php $this->load->view('load_js');?>

</html>
        