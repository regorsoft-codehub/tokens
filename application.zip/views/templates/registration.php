    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="<?php echo base_url('assets/css/animate.min.css')?>" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="<?php echo base_url('assets/css/light-bootstrap-dashboard.css')?>" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url('assets/css/custom.css')?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/demo.css')?>" rel="stylesheet" />


    <!-- Fonts and icons -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url('assets/css/pe-icon-7-stroke.css')?>" rel="stylesheet" />
    
<div class="login-body">
    <article class="container-login center-block">
		<section>
<!--			<ul id="top-bar" class="nav nav-tabs nav-justified">
				<li class="active">Accesso</li>
				<li>Password dimenticata</li>
			</ul>-->
			<div class="tab-content tabs-login col-lg-12 col-md-12 col-sm-12 cols-xs-12">
				<div id="login-access" class="tab-pane fade active in">
					<h2><i class="icon-chevron-sign-up"></i>&nbsp;CLIENT REGISTRATION</h2>	
                                        
                                            <?php if(validation_errors()){ ?>
                                               <?php  echo "<div class='errors'>".validation_errors()."</div>";?>
                                            <?php } ?>
                                           
                                            <?php $attributes = array('class' => 'form-horizontal', 'id' => 'myform', 'method'=>'post');
                                          echo form_open('registration/client', $attributes);?>
                                         
						<div class="form-group ">
							<label for="name" class="sr-only">Name</label>
							<input type="text" class="form-control" value="<?=set_value('name')?>" name="name" id="login_value" placeholder="Enter name" tabindex="1" value="" />
						</div>
						<div class="form-group ">
							<label for="surname" class="sr-only">Surname</label>
								<input type="surname" class="form-control" name="surname" id="password" value="<?=set_value('surname')?>" placeholder="Enter surname" value="" tabindex="2" />
						</div>
                                                <div class="form-group ">
							<label for="email" class="sr-only">Email</label>
								<input type="email" class="form-control" name="email" id="password"
									placeholder="Enter your email" value="<?=set_value('email')?>" tabindex="2" />
						</div>
                                                <div class="form-group ">
							<label for="password" class="sr-only">password</label>
								<input type="password" class="form-control" name="password" id="password"
									placeholder="Enter your password" value="" tabindex="2" />
						</div>
                                                <div class="form-group ">
							<label for="birthdate" class="sr-only">birthdate</label>
								<input id="datepicker" type="birthdate" class="form-control" name="birthdate" id="password"
									placeholder="Enter birthdate" value="<?=set_value('birthdate')?>" tabindex="2" />
						</div>
						<div class="form-group ">
							<label for="birthplace" class="sr-only">birthplace</label>
								<input type="birthplace"  class="form-control"  id="password"
									placeholder="Enter your birthplace" name="bp" value="<?=set_value('bp')?>" tabindex="2" />
						</div>
						<div class="form-group ">
							<label for="nationality" class="sr-only">nationality</label>
								<input type="text"  class="form-control" name="nationality" id="nn"
									placeholder="Enter your nationality" value="<?=set_value('nationality')?>" tabindex="2" />
                                                                </div>
                                                                <div class="form-group ">
                                                                   <label for="nnumber" class="sr-only">national number</label>
                                                                        <input type="nnumber"  class="form-control" name="nnumber" id="nn" placeholder="Enter your national number" value="<?=set_value('nnumber')?>" tabindex="2" />
                                                                </div>
                                                                <div class="form-group ">
                                                                     <label for="idcardno" class="sr-only">Id card number</label>
                                                                           <input type="text"  class="form-control" name="idcardno" id="nn" placeholder="Enter your Id card number" value="" tabindex="2" />
                                                                </div>
                                                                <div class="form-group "><label for="address" class="sr-only">eg. 12/123 Some Street</label>
                                                                     <input id="autocomplete" placeholder="Address eg. 12/123 Some Street" onFocus="geolocate()" type="text" value="<?=set_value('address')?>" class="form-control" name="address" id="nn"  value="" tabindex="2" />
                                                                </div>
                                                                <div class="form-group "> <label for="sn" class="sr-only">sn</label>
                                                                        <input id="street_number" type="text"  class="form-control" name="sn" id="nn"  placeholder="Street number" value="<?=set_value('sn')?>" tabindex="2" />
                                                                </div>
                                                                <div class="form-group ">
                                                                       <input type="text"  class="form-control" name="street2" id="route" placeholder="Enter your route" value="<?=set_value('street2')?>"  tabindex="2" />
                                                                </div>
                                                                <div class="form-group "> <label for="country" class="sr-only">country</label>
                                                                        <input type="text" id="country" class="form-control" name="country" id="nn" placeholder="Enter your country" value="<?=set_value('country')?>" tabindex="2" />
                                                                </div>
                                                                <div class="form-group "> <label for="City" class="sr-only">City</label>
                                                                    <input id="locality" type="text"  class="form-control" name="city" id="nn" placeholder="Enter your city" value="<?=set_value('city')?>" tabindex="2" />
                                                                </div>
                                                                <div class="form-group "> <label for="State" class="sr-only">Region</label>
                                                                        <input id="administrative_area_level_1" type="text"  class="form-control" name="region" id="nn"  placeholder="Enter your Region" value="<?=set_value('region')?>" tabindex="2" />
                                                                </div>
                                                                 <div class="form-group "> <label for="pc" class="sr-only">Postal code</label>
                                                                    <input id="postal_code" type="text"  class="form-control" name="pc" id="nn" placeholder="Postal code" value="<?=set_value('pc')?>" tabindex="2" />
                                                                </div>
                                                                <div class="form-group "> <label for="gsm" class="sr-only">gsm</label>
                                                                       <input type="text"  class="form-control" name="gsm" id="nn" placeholder="Enter your gsm" value="<?=set_value('gsm')?>" tabindex="2" />
                                                                </div>
                                                                
                                        
						<br/>
						<div class="form-group ">				
								<button type="submit" name="submit" id="submit" tabindex="5" class="btn btn-lg btn-primary">Register</button>
						</div>
                                                <span>Already have an account, log in <a href="<?php echo base_url('login')?>">Here</a></span>
                                                <?php $this->load->view('alerts_view'); ?>
					</form>			
				</div>
			</div>
		</section>
	</article>
</div>
    

        <!-- Note: Selection of address components in this example is typical.
             You may need to adjust it for the locations relevant to your app. See
             https://developers.google.com/maps/documentation/javascript/examples/places-autocomplete-addressform
        -->




    <script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'long_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'long_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBCa0gsPQocT-PpBJa2Dt8ZWPriMPCh0Bc&libraries=places&callback=initAutocomplete"
        async defer></script>
  </body>



    
    
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>    
 <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>    
  <style>
      div#ui-datepicker-div {
    position: absolute;
    top: 341px!important;
    left: 581.5px;
    z-index: 1;
    display: block;
    border: none;
}
  </style>