<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Auth extends CI_Model
{
    
    public function is_postcode_exist($postcode)
    {
        $ql = $this->db->select('*')->from('postal_code')->where('code',$postcode)->get();

        if( $ql->num_rows() > 0 )
        {
            $id = $ql->row();
            return $id->id;
            
        } else {
            
            $postcode=['code'=>$postcode];
            $this->db->insert('postal_code', $postcode);
            return $insert_id = $this->db->insert_id();
        }
    }
    public function exception_handle($action,$tn,$w,$i)
    {
        if($action=="error")
        {
        (int)$i;
            for($j=1;$j<=$i;$j++){
            $this->db->where($w, $i);
            $this->db->delete($tn);
            }
        }
        else {

        }
    }

}